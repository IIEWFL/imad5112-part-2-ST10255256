package com.example.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.math.BigDecimal
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private var number1: TextView? = null
    private var number2: TextView? = null
    private var answer: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        number1 = findViewById(R.id.editTextNumber)
        number2 = findViewById(R.id.editTextNumber2)
        answer = findViewById(R.id.tvAnswer)

        val btnADD = findViewById<Button>(R.id.btnAdd)
        val btnSUBTRACT = findViewById<Button>(R.id.button3)
        val btnMULTIPLY = findViewById<Button>(R.id.button)
        val btnDIVISION = findViewById<Button>(R.id.button5)
        val btnSQUAREROOT = findViewById<Button>(R.id.button6)
        val btnPower = findViewById<Button>(R.id.button7)
        val btnSTATISTICSFUNCTION = findViewById<Button>(R.id.btnStat)

        btnADD.setOnClickListener {
            ADD()
        }

        btnSUBTRACT.setOnClickListener {
            SUBTRACT()
        }

        btnMULTIPLY.setOnClickListener {
            MULTIPLY()
        }

        btnDIVISION.setOnClickListener {
            DIVISION()
        }

        btnSQUAREROOT.setOnClickListener {
            SQUAREROOT()
        }

        btnPower.setOnClickListener {
            power()
        }
    }

    private fun SUBTRACT() {
        if (populated()) {
            val input1 = number1?.text.toString().trim().toBigDecimal()
            val input2 = number2?.text.toString().trim().toBigDecimal()
            val results = input1.subtract(input2)
            answer?.text = "$input1 - $input2= $results"
        }
    }


    private fun MULTIPLY() {
        if (populated()) {
            val input1 = number1?.text.toString().trim().toBigDecimal()
            val input2 = number2?.text.toString().trim().toBigDecimal()
            val results = input1.multiply(input2)
            answer?.text = "$input1 x $input2= $results"
        }
    }

    private fun DIVISION() {
        if (populated()) {
            val input1 = number1?.text.toString().trim().toBigDecimal()
            val input2 = number2?.text.toString().trim().toBigDecimal()
            if (input1.compareTo(BigDecimal.ZERO) == 0 || input2.compareTo(BigDecimal.ZERO) == 0) {
                answer?.text = "Please enter a number bigger than zero"
            } else {
                val result = input1 / input2
                answer?.text = "$result"

            }

        }
    }


    private fun SQUAREROOT() {
        TODO("Not yet implemented")
    }

    private fun power() {
        TODO("Not yet implemented")
    }


    private fun ADD() {

        if (populated(){

            val input1 = number1?.text.toString().trim().toBigDecimal()
            val input2 = number2?.text.toString().trim().toBigDecimal()
            val results = input1.add(input2)
            answer?.text = "$input1 + $input2= $results"
        }
    }

    private fun populated(): Boolean {

        var b = true
        if (number1?.text.toString().trim().isEmpty()) {
            number1?.error = "Required"
            b = false
        }
        if (number2?.text.toString().trim().isEmpty()) {
            number2?.error = "Required"
            b = false
        }

        return b

    }

   private fun squareRoot(){
       if (populated()){

           val input1 = number1?.text.toString().trim().toLong()
           val input2 = number2?.text.toString().trim().toLong()

           if (input1<0){
               var answer1 = input1.times(-1)
               var answer2 = squareRoot(answer1.toFloat())
               answer?.text = "sqr of $answer1 = $answer2"
           }else{
               var answer2 = sqrt(input1.toFloat())
               answer?.text = "sqr of $input1 = answer2"

           }
           if (input2<0){
               var answer3 = input2.times(-1)
               var answer4 = sqrt(answer3.toFloat())
               answer?.text = "sqr of $answer3 = $answer4"
           }else{
               var answer4 = sqrt(input2.toFloat())
               answer?.text = "sqr of $input2 = $answer4"
           }
       }

   }
    private fun exponent(){

        if (populated()) {
        }

    val insert1 = number1?.text.toString().trim().toBigDecimal()
    val insert2 = number2?.text.toString().trim().toBigDecimal()
    }
}
